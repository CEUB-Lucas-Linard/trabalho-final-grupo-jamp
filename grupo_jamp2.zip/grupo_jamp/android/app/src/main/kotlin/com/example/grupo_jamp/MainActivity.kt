package com.example.grupo_jamp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
